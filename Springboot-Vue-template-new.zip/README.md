# Springboot-Vue-template
Springboot-Vue 前后端分离


## 技术栈

后端：

- Spring boot
- Mysql
- mybatis-plus

前端：

- vue
- webpack